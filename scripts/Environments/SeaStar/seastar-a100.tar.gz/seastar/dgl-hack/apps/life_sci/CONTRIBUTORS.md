# Contributing to DGL-LifeSci

Contribution is always welcome. All contributions must go through pull requests
and code review.

Below is a list of community contributors for this project.

Contributors
------------
* [Chengqiang Lu](https://github.com/geekinglcq): Alchemy dataset; MPNN, MGCN and SchNet
* [Jiajing Hu](https://github.com/jjhu94): Weave
