#!/bin/sh

make clean
rm -rf build
rm -rf source/tutorials
rm -rf source/generated
