"""DGL-based package for applications in life science."""
from . import data
from . import model
from . import utils
from .libinfo import __version__
