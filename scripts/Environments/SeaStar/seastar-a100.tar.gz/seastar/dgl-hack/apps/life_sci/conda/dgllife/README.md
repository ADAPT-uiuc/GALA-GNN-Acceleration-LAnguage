# Conda Recipe

Build the package with `conda build .`