# C API and runtime

Borrowed and adapted from TVM project. (commit: 2ce5277)
