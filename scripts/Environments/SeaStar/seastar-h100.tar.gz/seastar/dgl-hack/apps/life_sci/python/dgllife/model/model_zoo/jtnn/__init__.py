"""JTNN Module"""
from .jtnn_vae import DGLJTNNVAE
